package com.example.kimhy.calendar;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
    }

    // It is going to Calender screen
    public void GoBack(View view) {
        Intent intent = new Intent(this, CalendarActivity.class);
        startActivity(intent);
    }

    public void SaveNote(View view) {

        // setup the alert builder
        AlertDialog.Builder dlgAlert = new  AlertDialog.Builder(this);
        dlgAlert.setTitle("Successful");
        dlgAlert.setMessage("Your note is saved completely.");

        // add a button
        dlgAlert.setPositiveButton("OK", null);

        // create and show the alert dialog
        AlertDialog dialog = dlgAlert.create();
        dialog.show();
    }
}
